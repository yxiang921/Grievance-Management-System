<link href="{{ asset('css/app.css') }}" rel="stylesheet">
<script src="{{ asset('js/app.js')}}"></script>
<script src="{{ asset('js/echarts.js') }}"></script>
