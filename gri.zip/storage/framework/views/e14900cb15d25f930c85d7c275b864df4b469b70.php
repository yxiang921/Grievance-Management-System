
<?php $__env->startSection('content'); ?>
    <div class="w-full h-auto mt-4 border border-gray-100 shadow-sm rounded-md p-4 bg-white">
        <div class="w-full flex flex-row justify-between items-center pr-2">
            <h1 class="font-semibold text-lg">Users List</h1>
            <a class="primary-btn" href="<?php echo e(route('admin.user.add')); ?>">Add new user</a>
        </div>
        <div class="w-full">
            <div class="w-full">
                <div class="w-full grid grid-cols-1 lg:grid-cols-3 gap-4">
                    <input type="text" class="primary-input" placeholder="User ID">
                    <input type="text" class="primary-input" placeholder="Phone Number">
                    <input type="text" class="primary-input" placeholder="Email Address">
                </div>
            </div>

            <div class="line w-full h-1 border-b-[1px] border-gray-100 my-4"></div>

            <input class="primary-input w-64" type="text" placeholder="Username">
            <input class="primary-input w-64 lg:mx-4" type="text" placeholder="Full Name">
            <button class="primary-btn w-28">Search</button>
        </div>
        <div class="w-full h-auto mt-8 hidden lg:block">
            <div class="w-full text-center border-collapse border-y border-gray-100 bg-white">
                <table class="min-w-full overflow-hidden">
                    <thead class="border-b-[1px] border-gray-100 h-12 text-gray-500">
                        <tr>
                            <th class="">User ID</th>
                            <th class="">Username</th>
                            <th class="">Full Name</th>
                            <th class="">Email</th>
                            <th class="">Phone Number</th>
                            <th class="">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="h-10 hover:bg-primary-100/5">
                                <td>USR<?php echo e($user->id); ?></td>
                                <td><?php echo e($user->username); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->phone_number); ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin.user.edit', ['user_id' => $user->id])); ?>"
                                        class="underline">Edit</a>
                                    <span class="px-2">|</span>
                                    <a href="<?php echo e(route('admin.user.delete', ['user_id' => $user->id])); ?>" class="underline">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="lg:hidden block mt-4">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white border border-gray-100 rounded-md shadow-sm mb-4 p-4">

                    <div class="flex justify-between">
                        <div class="text-gray-500 font-medium">User ID</div>
                        <div>
                            USR<?php echo e($user->id); ?>

                        </div>
                    </div>
                    <div class="flex justify-between">
                        <div class="text-gray-500 font-medium">Username</div>
                        <div>
                            <?php echo e($user->username); ?>

                        </div>
                    </div>
                    <div class="flex justify-between">
                        <div class="text-gray-500 font-medium">Full Name</div>
                        <div>
                            <?php echo e($user->name); ?>

                        </div>
                    </div>
                    <div class="flex justify-between">
                        <div class="text-gray-500 font-medium">Email</div>
                        <div>
                            <?php echo e($user->email); ?>

                        </div>
                    </div>
                    <div class="flex justify-between">
                        <div class="text-gray-500 font-medium">Phone Number</div>
                        <div>
                            <?php echo e($user->phone_number); ?>

                        </div>
                    </div>
                    <div class="flex justify-between">
                        <div class="text-gray-500 font-medium">Action</div>
                        <div>
                            <a href="" class="underline">Edit</a>
                        </div>
                    </div>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\grievance-system\resources\views/admin/users.blade.php ENDPATH**/ ?>