

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto p-4">
        <div class="flex flex-col items-start justify-start mb-4">
            <div class="flex flex-col lg:flex-row w-full text-gray-500">
                <div class="w-full lg:w-1/4">
                    <input type="text" placeholder="Search by title"
                        class="transition-all w-full h-12 px-4 py-2 border  rounded-md focus:outline-none focus:ring-1 focus:ring-primary-100 focus:border-primary-900">
                </div>
                <div class="w-full lg:w-1/4 my-4 mx-0 lg:my-0 lg:mx-4">
                    <input type="date"
                        class="transition-all   w-full h-12 px-4 py-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-primary-100 focus:border-primary-900">
                </div>
                <div class="w-full lg:w-1/4">
                    <?php if (isset($component)) { $__componentOriginaleb2599921802e4a38571eaaa1488d4487c24c72d = $component; } ?>
<?php $component = App\View\Components\FilterDropdown::resolve(['items' => ['Received', 'In-Progress', 'Closed'],'label' => 'Select Status'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filter-dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FilterDropdown::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleb2599921802e4a38571eaaa1488d4487c24c72d)): ?>
<?php $component = $__componentOriginaleb2599921802e4a38571eaaa1488d4487c24c72d; ?>
<?php unset($__componentOriginaleb2599921802e4a38571eaaa1488d4487c24c72d); ?>
<?php endif; ?>
                </div>
            </div>
            <div class="w-full md:w-1/6 my-2">
                <button class="primary-btn w-full">
                    Search
                </button>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 md:grid-cols-2 gap-4">
            <?php $__currentLoopData = $grievances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grievance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginal0a892248b42edbb08c7a75ae7ab3215b0e70de84 = $component; } ?>
<?php $component = App\View\Components\GrievanceCard::resolve(['grievance' => $grievance] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('grievance-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GrievanceCard::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0a892248b42edbb08c7a75ae7ab3215b0e70de84)): ?>
<?php $component = $__componentOriginal0a892248b42edbb08c7a75ae7ab3215b0e70de84; ?>
<?php unset($__componentOriginal0a892248b42edbb08c7a75ae7ab3215b0e70de84); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\grievance-system\resources\views/department/grievances.blade.php ENDPATH**/ ?>