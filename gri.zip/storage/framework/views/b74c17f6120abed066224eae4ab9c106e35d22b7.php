
<?php $__env->startSection('content'); ?>
    <div class="w-full border border-gray-100 rounded-md p-4">
        <h1 class="text-lg font-medium">Add Department</h1>
        <form method="POST" action="<?php echo e(route('admin.department.create')); ?>" class="mt-4">
            <?php echo csrf_field(); ?>
            <div class="grid lg:grid-cols-4 items-center mt-4">
                <label for="departmentName" class="col-span-1">Department Name</label>
                <input type="text" class="primary-input col-span-2 mt-2 lg:mt-0" placeholder="Name"
                    name="departmentName" />
            </div>

            <div class="grid lg:grid-cols-4 items-center mt-4">
                <label for="departmentKey" class="col-span-1">Department Key</label>
                <input type="text" class="primary-input col-span-2 mt-2 lg:mt-0" placeholder="Department Key"
                    name="departmentKey" />
            </div>

            <div class="grid lg:grid-cols-4 items-center mt-4">
                <label for="departmentPassword" class="col-span-1">Department Password</label>
                <input type="password" class="primary-input col-span-2 mt-2 lg:mt-0"
                    name="departmentPassword" />
            </div>

            <div class="grid lg:grid-cols-4 items-center mt-4">
                <label for="departmentCategory" class="col-span-1">Categry</label>
                <select name="departmentCategory" id=""
                    class="primary-select w-full rounded-md border border-gray-400 text-gray-400">
                    <option value="Academic">Academic</option>
                    <option value="Facility">Facility</option>
                    <option value="Finance">Finance</option>
                    <option value="Behaviour">Behaviour</option>
                    <option value="Others">Others</option>
                </select>
            </div>
            <div class="mt-8">
                <a class="cancel-btn" href="<?php echo e(route('admin.departments')); ?>" >Cancel</a>
                <button class="primary-btn" type="submit">Submit</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\grievance-system\resources\views/admin/addDepartment.blade.php ENDPATH**/ ?>