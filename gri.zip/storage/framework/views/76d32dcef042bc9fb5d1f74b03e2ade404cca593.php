<?php
    use Carbon\Carbon;
    use Illuminate\Support\Str;
?>

<div class="bg-gray-50 p-4 rounded-lg shadow-lg  mt-2">
    <span class="text-sm text-green-500 font-semibold"><?php echo e($grievance->category); ?> Issue</span>
    <p class="mt-1"><?php echo e(Str::limit($grievance->title, 30, '...')); ?></p>
    <p class="text-gray-500 text-sm text-justify">
        <?php echo e(Str::limit($grievance->description, 100, '...')); ?>

    </p>
    <p class="text-gray-400 text-xs mt-2">
        <?php echo e($grievance->name); ?>

        <br>
        <?php echo e(Carbon::parse($grievance->grievance_created_at)->format('h : m A')); ?>

        <br>
        <?php echo e(Carbon::parse($grievance->grievance_created_at)->format('d F Y')); ?>,
        <br>
        <?php echo e($grievance->location); ?>

    </p>
</div>
<?php /**PATH D:\laragon\www\grievance-system\resources\views/components/kanban-card.blade.php ENDPATH**/ ?>