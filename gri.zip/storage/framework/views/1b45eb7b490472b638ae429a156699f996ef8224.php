<h1>

    Welcome, Department,
</h1><?php /**PATH D:\laragon\www\grievance-system\resources\views/home.blade.php ENDPATH**/ ?>