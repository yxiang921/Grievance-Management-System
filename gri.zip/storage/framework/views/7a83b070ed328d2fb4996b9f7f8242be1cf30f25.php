<!-- resources/views/login.blade.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h1>Login</h1>
    <form id="loginForm">
        <input type="email" id="email" placeholder="Email" required>
        <input type="password" id="password" placeholder="Password" required>
        <button type="submit">Login</button>
    </form>

    <!-- Load compiled JS -->
    <script src="<?php echo e(mix('/js/auth.js')); ?>"></script>

    <!-- Use Firebase functions for user login -->
    <script>
        document.getElementById('loginForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;

            try {
                const userCredential = await signInWithEmailAndPassword(auth, email, password);
                const user = userCredential.user;

                // 获取 ID token
                const idToken = await user.getIdToken();

                // 将 ID token 发送到后端 Laravel 服务器
                const response = await fetch('/firebase-login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                    },
                    body: JSON.stringify({ idToken })
                });

                if (response.ok) {
                    window.location.href = '/dashboard';
                } else {
                    console.error('Login failed');
                }

            } catch (error) {
                console.error('Error logging in:', error.message);
            }
        });
    </script>
</body>
</html>
<?php /**PATH D:\laragon\www\grievance-system\resources\views/login.blade.php ENDPATH**/ ?>