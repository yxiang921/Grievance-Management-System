<!-- resources/views/register.blade.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
</head>
<body>
    <h1>Register</h1>
    <form id="registerForm">
        <input type="email" id="email" placeholder="Email" required>
        <input type="password" id="password" placeholder="Password" required>
        <button type="submit">Register</button>
    </form>

    <!-- Load compiled JS -->
    <script src="<?php echo e(mix('/js/auth.js')); ?>"></script>

    <!-- Use Firebase functions for user registration -->
    <script>
        document.getElementById('registerForm').addEventListener('submit', (e) => {
            e.preventDefault();
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;

            createUserWithEmailAndPassword(auth, email, password)
                .then((userCredential) => {
                    console.log('User registered:', userCredential.user);
                    window.location.href = '/login';
                })
                .catch((error) => {
                    console.error('Error registering:', error.message);
                });
        });
    </script>
</body>
</html>
<?php /**PATH D:\laragon\www\grievance-system\resources\views/register.blade.php ENDPATH**/ ?>