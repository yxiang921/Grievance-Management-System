<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="<?php echo e(asset('js/echarts.js')); ?>"></script>
<?php /**PATH D:\laragon\www\grievance-system\resources\views/layouts/partials/head.blade.php ENDPATH**/ ?>