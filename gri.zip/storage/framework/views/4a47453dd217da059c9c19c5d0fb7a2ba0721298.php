
<?php $__env->startSection('content'); ?>
    <div class="w-full border border-gray-100 rounded-md p-4">
        <h1 class="text-lg font-medium">Edit Department</h1>
        <form class="mt-4" action="<?php echo e(route('admin.department.update')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <input type="hidden" name="departmentId" value="<?php echo e($department->id); ?>" />
            
            <div class="grid lg:grid-cols-4 items-center mt-4">
                <label for="departmentName" class="col-span-1">Department Name</label>
                <input type="text" class="primary-input col-span-2 mt-2 lg:mt-0" placeholder="Name" name="departmentName"
                    value="<?php echo e($department->department_name); ?>" />
            </div>

            <div class="grid lg:grid-cols-4 items-center mt-4">
                <label for="departmentKey" class="col-span-1">Department Key</label>
                <input type="text" class="primary-input col-span-2 mt-2 lg:mt-0" placeholder="Name" name="departmentKey"
                    value="<?php echo e($department->department_key); ?>" />
            </div>

            <div class="grid lg:grid-cols-4 items-center mt-4">
                <label for="departmentPassword" class="col-span-1">Department Password</label>
                <input type="password" class="primary-input col-span-2 mt-2 lg:mt-0" name="departmentPassword"
                    value="<?php echo e($department->department_password); ?>" />
            </div>


            <div class="grid lg:grid-cols-4 items-center mt-4">
                <label for="departmentCategory" class="col-span-1">Categry</label>
                <select name="departmentCategory" id=""
                    class="primary-select w-full rounded-md border border-gray-400 text-gray-400">
                    <option value="Academic" <?php echo e($department->department_category == 'Academic' ? 'selected' : ''); ?>>Academic
                    </option>
                    <option value="Facility" <?php echo e($department->department_category == 'Facility' ? 'selected' : ''); ?>>Facility
                    </option>
                    <option value="Finance" <?php echo e($department->department_category == 'Finance' ? 'selected' : ''); ?>>Finance
                    </option>
                    <option value="Behaviour" <?php echo e($department->department_category == 'Behaviour' ? 'selected' : ''); ?>>
                        Behaviour</option>
                    <option value="Others" <?php echo e($department->department_category == 'Others' ? 'selected' : ''); ?>>Others
                    </option>
                </select>
            </div>
            <div class="mt-8">
                <a class="cancel-btn" href="<?php echo e(route('admin.departments')); ?>">Cancel</a>
                <button class="primary-btn" type="submit">Update</button>
            </div>

        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\grievance-system\resources\views/admin/editDepartment.blade.php ENDPATH**/ ?>