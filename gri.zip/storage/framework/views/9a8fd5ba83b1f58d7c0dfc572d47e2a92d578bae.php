
<?php $__env->startSection('content'); ?>
    <div class="w-full h-auto mt-4 border border-gray-100 shadow-sm rounded-md p-4 bg-white">
        <div class="w-full flex flex-col lg:flex-row lg:items-center justify-between">
            <div class="">
                <input class="primary-input w-64" type="text" placeholder="Search department name">
                <button class="primary-btn w-28 ml-2">Search</button>
            </div>
            <div class="">
                <a class="primary-btn" href="<?php echo e(route('admin.department.add')); ?>">Add New Department</a>
            </div>
        </div>
        <div class="w-full h-auto mt-8 hidden lg:block">
            <div class="w-full text-center border-collapse border-y border-gray-100 bg-white">
                <table class="min-w-full overflow-hidden">
                    <thead class="border-b-[1px] border-gray-100 h-12 text-gray-500">
                        <tr>
                            <th class="">Department ID</th>
                            <th class="">Department Key</th>
                            <th class="">Department Name</th>
                            <th class="">Category</th>
                            <th class="">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="h-10">
                                <td>
                                    DPM<?php echo e($department->id); ?>

                                </td>
                                <td>
                                    <?php echo e($department->department_key); ?>

                                </td>
                                <td>
                                    <?php echo e($department->department_name); ?>

                                </td>
                                <td>
                                    <?php echo e($department->department_category); ?>

                                </td>
                                <td>
                                    <a href="<?php echo e(route('admin.department.edit', ['department_id' => $department->id])); ?>"
                                        class="underline">Edit</a>
                                    <span class="p-2">|</span>
                                    <a href="<?php echo e(route('admin.department.delete', ['department_id' => $department->id])); ?>"
                                        class="underline">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>


        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="lg:hidden block mt-4">
                <div class="bg-white border border-gray-100 rounded-md shadow-sm mb-4 p-4">
                    <div class="flex justify-between">
                        <div class="text-gray-500 font-medium">Department ID</div>
                        <div>
                            DPM<?php echo e($department->id); ?>

                        </div>
                    </div>
                    <div class="flex justify-between">
                        <div class="text-gray-500 font-medium">Department Key</div>
                        <div>
                            <?php echo e($department->department_key); ?>

                        </div>
                    </div>
                    <div class="flex justify-between">
                        <div class="text-gray-500 font-medium">Department Name</div>
                        <div>
                            <?php echo e($department->department_name); ?>

                        </div>
                    </div>
                    <div class="flex justify-between">
                        <div class="text-gray-500 font-medium">Category</div>
                        <div>
                            <?php echo e($department->department_category); ?>

                        </div>
                    </div>
                    <div class="flex justify-between">
                        <div class="text-gray-500 font-medium">Action</div>
                        <div>
                            <a href="" class="underline">Edit</a>
                        </div>
                    </div>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\grievance-system\resources\views/admin/departments.blade.php ENDPATH**/ ?>