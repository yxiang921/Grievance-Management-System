<?php
use Illuminate\Support\Str;

    $status = $grievance->status;
    $badgeClass = [
        'Received' => 'received-badge',
        'In Progress' => 'in-progress-badge',
        'Closed' => 'closed-badge',
    ];
?>

<div class="bg-white p-4 rounded-lg shadow-md flex flex-col items-start justify-between">
    <div class="flex items-center mb-4">
        <img src="http://picsum.photos/200/200" alt="Avatar" class="w-12 h-12 rounded-full">
        <div class="ml-4">
            <h3 class="text-lg font-semibold"><?php echo e($grievance->name); ?></h3>
            <p class="text-gray-600"><?php echo e($grievance->email); ?></p>
        </div>
    </div>
    <span class="status-badge
        <?php echo e($badgeClass[$status]); ?>

        "><?php echo e($grievance->status); ?></span>
    <h4 class="text-lg font-semibold my-2">
        <?php echo e(Str::limit($grievance->title, 30, '...')); ?>

    </h4>
    <p class="text-gray-600 mb-4 text-justify">
        <?php echo e(Str::limit($grievance->description, 100, '...')); ?>

    </p>
    <button class="md:w-1/2 w-full primary-btn"
        onclick="window.location.href = '<?php echo e(route('admin.grievance.detail', ['grievance_id' => $grievance->grievance_id])); ?>'">
        Read
    </button>
</div>


<?php /**PATH D:\laragon\www\grievance-system\resources\views/components/grievance-card.blade.php ENDPATH**/ ?>